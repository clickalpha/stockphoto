=== Add & Replace Affiliate Links for Amazon ===
Contributors: hekkup
Donate link:  https://hekkup.com
Tags: amazon, affilate links
Requires at least: 4.0
Tested up to: 5.2.5
Requires PHP: 7.0
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Add & Replace Affiliate Links for Amazon plugin helps you to add/update tag parameters in links that follows to amazon.

You can add/update paratemer in posts/pages across the website. It's also allows you to backup/revert changes made by plugin.

Also, it allows you to see which pages were modified. 

BE CAREFUL! MAKE BACKUP BEFORE EACH UPDATE TO SAVE YOU DATA, SO YOU COULD REVERT POSTS STATE THAT WERE UPDATED.

== Installation ==

1. Upload the Add & Replace Affiliate Links for Amazon plugin to your wordpress website. 
2. Activate it.
3. Then you'll find the new menu items in sidebar.
4. There you can enter desired tag and add/update all the links across website.

== Frequently Asked Questions ==

No F.A.Q. available

== Screenshots ==

1. No screenshots available

== Changelog ==

= 1.0.0 =
* Release Date - 19 December 2019*
* Plugin create
* Add Support for short and full amazon links

= 1.0.1 =
* Release Date - 29 December 2019*
* Check permission per post/page during update/backup processes
* Add ajax support

= 1.0.2 =
* Release Date - 29 December 2019*
* Add preloader icon
* Fixed readme file
* Make unique callback actions with prefixes

= 1.0.2 =
* Release Date - 08 March 2020*
* Add ability to make only expand shortended links
* Add ability to add no-follow attribute for amazon links
* Add ability to remove tags from affiliate tags

== Upgrade Notice ==

= 1.0.0 =
To use plugin

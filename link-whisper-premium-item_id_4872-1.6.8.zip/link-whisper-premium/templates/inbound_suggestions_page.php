<div class="wrap wpil-report-page wpil_styles" id="inbound_suggestions_page" data-id="<?=$post->id?>" data-type="<?=$post->type?>">
    <?=Wpil_Base::showVersion()?>
    <?php $same_category = !empty(get_user_meta(get_current_user_id(), 'wpil_same_category_selected', true)) ? '&same_category=true': ''; ?>
    <h1 class="wp-heading-inline"><?php _e("Inbound links suggestions", "wpil"); ?></h1>
    <a href="<?=esc_url($return_url)?>" class="page-title-action return_to_report"><?php _e('Return to Report','wpil'); ?></a>
    <h2><?php _e('Creating links pointing to: ', 'wpil'); ?><a href="<?php echo $post->getViewLink(); ?>"><?php echo $post->getTitle();?></a></h2>
    <div id="keywords">
        <form action="" method="post">
            <label for="keywords_field">Search by Keyword</label>
            <textarea name="keywords" id="keywords_field"><?=!empty($_POST['keywords'])?sanitize_textarea_field($_POST['keywords']):''?></textarea>
            <button type="submit" class="button-primary">Search</button>
        </form>
    </div>
    <div id="wpil-inbound-target-keywords">
        <div class="wpil-inbound-target-keyword-edit-button"><button class="button-primary" data-nonce="<?php echo wp_create_nonce('wpil-inbound-keyword-visibility-nonce'); ?>"><?php _e('Edit Target Keywords', 'wpil'); ?></button></div>
        <div class="wpil-inbound-target-keyword-edit-form" style="<?php echo (empty(get_user_meta(get_current_user_id(), 'wpil_inbound_target_keyword_visible', true))) ? 'display: none;' : ''; ?>"><?php
            $user = wp_get_current_user();
            $keywords = Wpil_TargetKeyword::get_keywords_by_post_ids($post->id, $post->type);
            $keyword_sources = Wpil_TargetKeyword::get_active_keyword_sources();?>
            <div id="wpil_target-keywords" class="postbox ">
                <h2 class="hndle no-drag"><span><?php _e('Link Whisper Target Keywords', 'wpil'); ?></span></h2>
                <div class="inside"><?php
                    $is_metabox = false;
                    include WP_INTERNAL_LINKING_PLUGIN_DIR . '/templates/target_keyword_list.php';?>
                </div>
            </div>
        </div>
    </div>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">

                <?php if (!empty($message_error)) : ?>
                    <div class="notice notice-error is-dismissible"><?=$message_error?></div>
                <?php endif; ?>

                <?php if (!empty($message_success)) : ?>
                    <div class="notice notice-success is-dismissible"><?=$message_success?></div>
                <?php endif; ?>

                <div id="wpil_link-articles" class="postbox">
                    <h2 class="hndle no-drag"><span><?php _e('Link Whisper Inbound Suggestions', 'wpil'); ?></span></h2>
                    <div class="inside">
                        <div class="tbl-link-reports">
                            <?php $user = wp_get_current_user(); ?>
                            <?php if (!empty($_GET['wpil_no_preload'])) : ?>
                                <form method="post" action="">
                                    <div data-wpil-ajax-container data-wpil-ajax-container-url="<?=esc_url(admin_url('admin.php?page=link_whisper&type=inbound_suggestions_page_container&'.($post->type=='term'?'term_id=':'post_id=').$post->id.(!empty($user->ID) ? '&nonce='.wp_create_nonce($user->ID . 'wpil_suggestion_nonce') : '')).Wpil_Suggestion::getKeywordsUrl().'&wpil_no_preload=1' . $same_category); ?>">
                                        <div style="margin-bottom: 15px;">
                                            <input style="margin-bottom: -5px;" type="checkbox" name="same_category" id="field_same_category_page" <?=(isset($same_category) && !empty($same_category)) ? 'checked' : ''?>> <label for="field_same_category_page">Only Show Link Suggestions in the Same Category as This Post</label>
                                            <br>
                                            <input type="checkbox" name="same_tag" id="field_same_tag" <?=!empty($same_tag) ? 'checked' : ''?>> <label for="field_same_tag">Only Show Link Suggestions with the Same Tag as This Post</label>
                                        </div>
                                        <button id="inbound_suggestions_button" class="sync_linking_keywords_list button-primary" data-id="<?=esc_attr($post->id)?>" data-type="<?=esc_attr($post->type)?>" data-page="inbound">Add links</button>
                                    </div>
                                </form>
                            <?php else : ?>
                            <div data-wpil-ajax-container data-wpil-ajax-container-url="<?=esc_url(admin_url('admin.php?page=link_whisper&type=inbound_suggestions_page_container&'.($post->type=='term'?'term_id=':'post_id=').$post->id.(!empty($user->ID) ? '&nonce='.wp_create_nonce($user->ID . 'wpil_suggestion_nonce') : '')).Wpil_Suggestion::getKeywordsUrl() . $same_category)?>">
                                <div class='progress_panel loader'>
                                    <div class='progress_count' style='width: 100%'></div>
                                </div>
                            </div>
                            <p style="margin-top: 50px;">
                                <a href="<?=esc_url($_SERVER['REQUEST_URI'] . '&wpil_no_preload=1')?>">Load without animation</a>
                            </p>
                            <?php endif; ?>
                            <div data-wpil-page-inbound-links=1> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
